import { ApolloClient, HttpLink, InMemoryCache } from '@apollo/client'
import dotenv from 'dotenv'
import fetch from 'node-fetch'
import { getSeedMutations } from './seed-mutations'

dotenv.config()

const {
  GRAPHQL_SERVER_HOST: host,
  GRAPHQL_SERVER_PORT: port,
  GRAPHQL_SERVER_PATH: path,
} = process.env

const uri = `http://${host}:${port}${path}`
console.log("my URI: "+uri)
const client = new ApolloClient({
  link: new HttpLink({ uri, fetch }),
  cache: new InMemoryCache(),
})
var count = 0
console.log(client.localState)
const runMutations = async () => {
  const mutations = await getSeedMutations()

  return Promise.all(
    mutations.map(({ mutation, variables }) => {
      count++
      //console.log(count)
      return client
        .mutate({
          mutation,
          variables,
        })
        .catch((e) => {
          throw new Error(e)
        })
    })
  )
}
console.log("back to seed js")
runMutations()
  .then(() => {
    console.log('Database seeded!')
  })
  .catch((e) => console.error(e))
