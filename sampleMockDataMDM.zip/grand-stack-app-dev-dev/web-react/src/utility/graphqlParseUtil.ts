// query node for nodeId
export function exploreData(data: Array<string>) {
  console.log(typeof data)
  console.log(data)
  console.log(data[0])
}
