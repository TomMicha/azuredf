import React from 'react'

//import { useQuery, gql } from '@apollo/client'
import Title from './Title'
import GraphMini from './GraphMini'
// const CITY_REGION_QUERY = gql`
//   {
//     locationStates(options: { limit: 5, sort: { modified: DESC } }) {
//       id
//       city
//       state
//       country
//       modified
//     }
//   }
// `

export default function Graph() {
  //const { classes } = useStyles()
  //   const { loading, error, data } = useQuery(CITY_REGION_QUERY)
  //   if (error) return <p>Error</p>
  //   if (loading) return <p>Loading</p>

  return (
    <React.Fragment>
      <Title>Node experiment</Title>

      <GraphMini />
    </React.Fragment>
  )
}
