import React from 'react'
// import { useTheme } from '@material-ui/core/styles'
// import { Grid, Paper } from '@material-ui/core'
// import { makeStyles } from '@material-ui/core/styles'
// import clsx from 'clsx'

import { useQuery } from '@apollo/client'

import {
  getPolicyCount,
  getUnmasteredPolicyCount,
  getPolicies,
} from '../actions/getPolicies'
import { Typography } from '@material-ui/core'
import { GenericDataGrid } from './PolicyGrid'

const generateColsObj = (row) => {
  const valuesToRemove = ['__typename']
  let cols = row && Object.keys(row)
  cols = cols
    .map((item) => {
      if (!valuesToRemove.includes(item)) {
        return {
          field: item,
          headerName: item,
          flex: 1,
          type: 'string',
          headerAlign: 'left',
        }
      }
    })
    .filter((item) => item)
  return cols
}

const unpackObj = (obj, nestedObj) => {
  if (obj && obj[nestedObj]) {
    let newObj = { ...obj, ...obj[nestedObj] }

    return newObj
  } else return obj
}

const arrayIsNotEmpty = (array) => {
  if (!Array.isArray(array) || !array.length) {
    return false
  } else return true
}

const unpackObjArray = (arr, nestedObj) => {
  return arr.map((obj) => {
    return unpackObj(obj, nestedObj)
  })
}

const pick = (obj, props) => {
  // Make sure object and properties are provided
  if (!obj || !props) return

  // Create new object
  let picked = {}

  // Loop through props and push to new object
  props.forEach(function (prop) {
    picked[prop] = obj[prop]
  })

  // Return new object
  return picked
}

const filterObjectArray = (arr, filters) => {
  let newArr = [...arr]
  return newArr.map((obj) => {
    let diff = Object.keys(obj).filter((x) => !filters.includes(x))
    return pick(obj, diff)
  })
}

export default function Policy() {
  const stateName = 'currentState'
  let {
    loading: loadingPolicyCount,
    error: errorPolicyCount,
    data: { policiesCount = 0 } = {},
  } = useQuery(getPolicyCount)

  // let { policiesCount = 'Loading' } = loading ? 'Loading' : data

  let {
    loading: loadingUMPolicy,
    error: errorUMPolicy,
    data: dataUMPolicy,
  } = useQuery(getUnmasteredPolicyCount)
  let { unmasteredPolicyCount: UMPolicyCount = 'Loading' } = loadingUMPolicy
    ? 'Loading'
    : dataUMPolicy
  // const theme = useTheme()

  // const useStyles = makeStyles((theme) => ({
  //   root: {
  //     display: 'flex',
  //   },
  //   paper: {
  //     padding: theme.spacing(2),
  //     display: 'flex',
  //     overflow: 'auto',
  //     flexDirection: 'column',
  //   },
  //   fixedHeight: {
  //     height: 240,
  //   },
  // }))
  // const classes = useStyles(theme)
  // const fixedHeightPaper = clsx(classes.paper, classes.fixedHeight)
  let { loading, error, data: { policies = [] } = [] } = useQuery(getPolicies)
  // const UMPolicyCount = 0
  let cols = [
    {
      field: 'policyVersionSk',
      headerName: 'policyVersionSk',
      flex: 1,
      type: 'number',
      headerAlign: 'left',
    },
    {
      field: 'policyCoverageEnds',
      headerName: 'policyCoverageEnds',
      flex: 1,
      type: 'string',
      headerAlign: 'left',
    },
    {
      field: 'policyCoverageStarts',
      headerName: 'policyCoverageStarts',
      flex: 1,
      type: 'string',
      headerAlign: 'left',
    },
    {
      field: 'policyPeriodEnds',
      headerName: 'policyPeriodEnds',
      flex: 1,
      type: 'string',
      headerAlign: 'left',
    },
    {
      field: 'policyPeriodStarts',
      headerName: 'policyPeriodStarts',
      flex: 1,
      type: 'string',
      headerAlign: 'left',
    },
    {
      field: 'policyStatus',
      headerName: 'policyStatus',
      flex: 1,
      type: 'string',
      headerAlign: 'left',
    },
  ]

  if (arrayIsNotEmpty(policies)) {
    policies = unpackObjArray(policies, stateName)
    policies = filterObjectArray(policies, [stateName, '__typename'])
    // cols = policies && policies[0] && generateColsObj(policies[0])
  }

  return (
    <React.Fragment>
      {/* {loading ? 'Loading...' : data.userCount} */}
      <div>{`Total Node Count: ${policiesCount}`}</div>
      {/* <div>{`Total Unmastered Polcy Node Count: ${UMPolicyCount}`}</div> */}
      <Typography variant="h4">{'Unmastered Policy Version SKs'}</Typography>
      <GenericDataGrid cols={cols} rows={policies} pk="policyVersionSk" />
    </React.Fragment>
  )
}
