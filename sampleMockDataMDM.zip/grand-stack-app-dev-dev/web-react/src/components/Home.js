import React from 'react'
//import { makeStyles } from '@material-ui/core/styles'
//import Typography from '@material-ui/core/Typography'
import Title from './Title'
//import { useQuery, gql } from '@apollo/client'

export default function Home() {
  //const { loading, error, data } = useQuery(GET_COUNT_QUERY)
  //if (error) return <p>Error</p>
  return (
    <React.Fragment>
      <Title>Landing Page</Title>
    </React.Fragment>
  )
}
