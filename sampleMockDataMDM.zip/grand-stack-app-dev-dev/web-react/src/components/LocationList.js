import React from 'react'
import { useQuery, gql } from '@apollo/client'
import { withStyles } from '@material-ui/core/styles'
//import Search from './Search'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Tooltip,
  Paper,
  TableSortLabel,
  TextField,
} from '@material-ui/core'

import Title from './Title'

const styles = (theme) => ({
  root: {
    maxWidth: 2300,
    marginTop: theme.spacing(2),
    overflowX: 'auto',
    margin: 'auto',
  },
  table: {
    minWidth: 1000,
  },
  textField: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
    minWidth: 250,
  },
})

const GET_LOCATION = gql`
  query locationsQuery(
    $first: Int
    $offset: Int
    $orderBy: [LocationSort]
    $filter: LocationWhere
  ) {
    locations(
      options: { limit: $first, offset: $offset, sort: $orderBy }
      where: $filter
    ) {
      locationId
      source
      sourceKey
      sourceId
      created
      locationState {
        address
        city
        state
        country
        modified
      }
    }
  }
`

function LocationList(props) {
  const { classes } = props
  const [order, setOrder] = React.useState('ASC')
  const [orderBy, setOrderBy] = React.useState('locationId')
  const [page] = React.useState(0)
  const [rowsPerPage] = React.useState(10)
  const [filterState, setFilterState] = React.useState({ entityFilter: '' })

  const getFilter = () => {
    return filterState.entityFilter.length > 0
      ? { locationId_CONTAINS: filterState.entityFilter }
      : {}
  }

  const { loading, data, error } = useQuery(GET_LOCATION, {
    variables: {
      first: rowsPerPage,
      offset: rowsPerPage * page,
      orderBy: { [orderBy]: order },
      filter: getFilter(),
    },
  })
  const handleSortRequest = (property) => {
    const newOrderBy = property
    let newOrder = 'DESC'

    if (orderBy === property && order === 'DESC') {
      newOrder = 'ASC'
    }

    setOrder(newOrder)
    setOrderBy(newOrderBy)
  }
  const handleFilterChange = (filterLocation) => (event) => {
    const val = event.target.value

    setFilterState((oldFilterState) => ({
      ...oldFilterState,
      [filterLocation]: val,
    }))
  }
  return (
    <Paper className={classes.root}>
      <div>
        <p>something brewin</p>
        <p>Need to test getting locationState details as well</p>
      </div>
      <Title>Search for Locations by LocationID</Title>
      <TextField
        id="locationId"
        label="pass ${locationId} search to qgl"
        className={classes.textField}
        value={filterState.entityFilter}
        onChange={handleFilterChange('entityFilter')}
        margin="normal"
        variant="outlined"
        type="text"
        InputProps={{
          className: classes.input,
        }}
      />
      {loading && !error && <p>Loading...</p>}
      {error && !loading && <p>Error</p>}
      {data && !loading && !error && (
        <Table className={classes.table}>
          <TableHead>
            <TableRow>
              <TableCell
                key="locationId"
                sortDirection={
                  orderBy === 'locationId' ? order.toLowerCase() : false
                }
              >
                <Tooltip title="Sort" placement="bottom-start" enterDelay={300}>
                  <TableSortLabel
                    active={orderBy === 'locationId'}
                    direction={order.toLowerCase()}
                    onClick={() => handleSortRequest('locationId')}
                  >
                    LocationId
                  </TableSortLabel>
                </Tooltip>
              </TableCell>
              <TableCell key="source">Source</TableCell>
              <TableCell key="sourceKey">SourceKey</TableCell>
              <TableCell key="sourceId">SourceId</TableCell>
              <TableCell key="address">Address</TableCell>
              <TableCell key="city">City</TableCell>
              <TableCell key="state">State</TableCell>
              <TableCell key="country">Country</TableCell>
              <TableCell key="zip">Zip</TableCell>
              <TableCell key="created">Created</TableCell>
              <TableCell key="modified">Modified</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {data.locations.map((n) => {
              return (
                <TableRow key={n.locationId}>
                  <TableCell component="th" scope="row">
                    {n.locationId}
                  </TableCell>
                  <TableCell>{n.source}</TableCell>
                  <TableCell>{n.sourceKey}</TableCell>
                  <TableCell>{n.sourceId}</TableCell>
                  <TableCell>{n.locationState.address}</TableCell>
                  <TableCell>{n.locationState.city}</TableCell>
                  <TableCell>{n.locationState.state}</TableCell>
                  <TableCell>{n.locationState.country}</TableCell>
                  <TableCell>{n.locationState.zip}</TableCell>
                  <TableCell>{n.created}</TableCell>
                  <TableCell>{n.locationState.modified}</TableCell>
                </TableRow>
              )
            })}
          </TableBody>
        </Table>
      )}
    </Paper>
  )
}

export default withStyles(styles)(LocationList)
