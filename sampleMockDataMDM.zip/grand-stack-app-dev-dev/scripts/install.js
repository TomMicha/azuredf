const concurrently = require('concurrently')

const {
  API_DIR,
  runner,
  concurrentOpts,
  REACT_DIR,
  ROOT_DIR,
} = require('./common')

const jobs = [
  {
    name: 'api-install',
    command: `cd ${API_DIR} && ${runner} install`,
    prefixColor: 'green',
  },
  {
    name: 'web-react-install',
    command: `cd ${REACT_DIR} && ${runner} install`,
    prefixColor: 'blue',
  },
  {
    name: 'root-install',
    command: `cd ${ROOT_DIR} && ${runner} install`,
    prefixColor: 'cyan',
  },
]

concurrently(jobs, concurrentOpts).catch((e) => {
  console.error(e.message)
})
