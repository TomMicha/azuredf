import React from 'react'
import { Chart } from 'react-d3-graph'
import { useQuery, gql } from '@apollo/client'

export default function ReGraph() {
  const { loading, error, data } = useQuery(gql`
    {
      users(first: 5) {
        name
        userId
      }
    }
  `)
  console.log(data)
  if (loading) return <p>Loading...</p>
  if (error) return <p>Error!</p>

  return (
    <div style={{ display: 'flex', width: '100vw', height: '100vh' }}>
      <Chart
        items={{ node: { label: { text: 'Welcome to ReGraph!' } } }}
        options={{}}
      />
    </div>
  )
}
