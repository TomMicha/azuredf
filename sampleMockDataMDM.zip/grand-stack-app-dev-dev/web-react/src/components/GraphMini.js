import React from 'react'
import { Graph } from 'react-d3-graph'
import { useQuery, gql } from '@apollo/client'
import Title from './Title'
import { ResponsiveContainer } from 'recharts'
// graph payload (with minimalist structure)
// const data2 = {
//   nodes: [
//     { id: 'Harry', data: { line: 'Hi', dob: 1999 } },
//     { id: 'Sally', data: { line: 'Bye', dob: 1998 } },
//     { id: 'Alice', data: { line: 'nonononyes', dob: 1990 } },
//   ],
//   links: [
//     { source: 'Harry', target: 'Sally', relationship: 'FRIEND' },
//     { source: 'Harry', target: 'Alice', relationship: 'FRIEND' },
//   ],
// }

//query by
const LOCATIONS_TEST = gql`
  {
    locations(options: { limit: 4 }) {
      locationId
      source
      sourceKey
      sourceId
      created
      current {
        address
        city
        state
        country
        modified
      }
    }
  }
`
// get locations and locations states? to test relationships?
// get all locationsIds in list, with that query need to get all relationships and related nodes
//the graph configuration, just override the ones you need
const myConfig = {
  nodeHighlightBehavior: true,
  linkHighlightBehavior: true,
  directed: true,
  height: 600,
  width: 800,
  collapsible: false,
  d3: {
    alphaTarget: 0.07,
    gravity: -130,
    linkLength: 100,
    linkStrength: 2,
    disableLinkForce: false,
  },
  node: {
    labelPosition: 'bottom',
    color: 'lightgreen',
    size: 300,
    fontSize: 14,
    highlightStrokeColor: 'blue',
    highlightFontSize: 18,
  },
  link: {
    highlightColor: 'lightblue',
    renderLabel: true,
    fontSize: 12,
    strokeWidth: 3,
    type: 'CURVE_SMOOTH',
  },
}
// can i get a const of data from gql saved
// find node
// const findNode = (nodeId, data) => {
//   return data.nodes.find((l) => l.id === nodeId)
// }

const onClickNode = function (nodeId, node) {
  // where this node id has property query?
  //val nodeA = findNode()
  console.log(node.data)
  window.alert(
    `Clicked node ${nodeId} // ${node.data.source}\n${node.data.sourceKey} \n${node.data.sourceId}\n${node.data.created}\n${node.data.locationId}\n${node.data.current_address}\n${node.data.current_city} \n${node.data.current_country}`
  )
}

const onClickLink = function (source, target) {
  console.log(source, target)
  window.alert(
    `Details for ${source}: //${source.data.locationId}// \n${source.data.sourceKey} \n${source.data.sourceId} \n ${source.data.locationId} \n
    ${source.data.current_address} \n${source.data.current_city} \n ${source.data.current_country}`
  )
}
const onDoubleClickNode = function (nodeId, node) {
  console.log(nodeId, node)
  window.alert(
    `Double clicked node ${nodeId} in position (${node.x}, ${node.y})`
  )
}
// const onMouseOverNode = function (nodeId, node) {
//   console.log(nodeId, node.data)
//     window.alert(
//       `Mouse over node ${nodeId} in position (${node.data}, ${node.y})`
//     )
// }
// const onMouseOutNode = function (nodeId, node) {
//   console.log(nodeId, node)
//   window.alert(`Mouse out node ${nodeId} in position (${node.x}, ${node.y})`)
// }
const onMouseOverLink = function (source, target) {
  console.log(source, target)
  //   window.alert(
  //     `Mouse over in link between ${source} and ${target} they are ${source}`
  //   )
}
function addRandomNum(num) {
  let i = Math.random()
  if (i < 0.5) {
    return num - Math.random() * 50 - 30
  }
  return Math.random() * 50 + 30 + num
}
// function to modify return graphql nodes into {nodes: [], links: [] } format
function modifyForGraph(data) {
  var counter = 0
  var mylist = []
  // cooordinates for initial node placement
  var x = 400
  var y = 300
  for (let i in data) {
    // extract nested entity attributes
    var properties = flattenObject(data[i])
    //console.log(properties)
    var addDict = { id: counter, data: properties, x: x, y: y }
    x = addRandomNum(x)
    y = addRandomNum(y)
    mylist.push(addDict)
    counter++
  }
  return {
    nodes: mylist,
    // for now -> fake data
    links: [
      {
        source: 0,
        target: 1,
        label: 'has_state',
        value: 11,
        fields: [{ name: 'testId', record: 4 }],
        required: false,
      },
      {
        source: 1,
        target: 2,
        label: 'test2',
        value: 22,
        fields: [{ name: 'WhatId', record: -1 }],
        required: false,
      },
      {
        source: 0,
        target: 3,
        label: 'test3',
        value: 33,
        fields: [{ name: 'WhatId', record: -3 }],
        required: false,
      },
    ],
  }
}
// simple function to replace given nested and un nest and add to list of properties
function flattenObject(ob, prefix = false, result = null) {
  result = result || {}

  // Preserve empty objects and arrays, they are lost otherwise
  if (
    prefix &&
    typeof ob === 'object' &&
    ob !== null &&
    Object.keys(ob).length === 0
  ) {
    result[prefix] = Array.isArray(ob) ? [] : {}
    return result
  }

  prefix = prefix ? prefix + '_' : ''

  for (const i in ob) {
    if (Object.prototype.hasOwnProperty.call(ob, i)) {
      if (typeof ob[i] === 'object' && ob[i] !== null) {
        // Recursion on deeper objects
        flattenObject(ob[i], prefix + i, result)
      } else {
        result[prefix + i] = ob[i]
      }
    }
  }
  return result
}
// function helperNested(nestedProp, listItem) {
//   var tempState = listItem[nestedProp]
//   var tempList = []
//   var temp = delete listItem[nestedProp]
//   console.log(temp)
//   for (let x in tempState) {
//     console.log(x)
//   }
//   return temp
// }
export default function GraphMini() {
  const { loading, error, data } = useQuery(LOCATIONS_TEST)

  if (error) return <p>Error</p>
  if (loading) return <p>Loading</p>
  //console.log(data)
  //exploreData(data.locations)
  var graphData = modifyForGraph(data.locations)
  console.log(graphData)

  return (
    <React.Fragment>
      <Title>Graph Nodes</Title>
      <ResponsiveContainer>
        <Graph
          id="graph-id" // id is mandatory
          data={graphData}
          config={myConfig}
          onClickNode={onClickNode}
          onClickLink={onClickLink}
          onDoubleClickNode={onDoubleClickNode}
          //onMouseOverNode={onMouseOverNode}
          //onMouseOutNode={onMouseOutNode}
          onMouseOverLink={onMouseOverLink}
        />
      </ResponsiveContainer>
    </React.Fragment>
  )
}
