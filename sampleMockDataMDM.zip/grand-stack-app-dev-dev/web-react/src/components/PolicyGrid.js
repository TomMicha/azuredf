import { DataGrid } from '@material-ui/data-grid'
import React from 'react'

const GenericDataGrid = (props) => {
  let { pk, cols = [], rows = [] } = props
  // let { loading, error, data = [] } = useQuery(query)
  // const valuesToRemove = ['__typename']
  // let cols = (unmasteredPolicies &&
  //   unmasteredPolicies[0] &&
  //   Object.keys(unmasteredPolicies[0])) || [pk]
  // cols = cols.map((item) => {
  //   if (!valuesToRemove.includes(item)){
  //     return { field: !valuesToRemove.includes(item) }
  //   }
  // })

  //   const cols = [
  //     {
  //       field: 'policyVersionSk',
  //       headerName: 'POLICY_VERSION_SK',
  //       flex: 1,
  //       type: 'number',
  //       headerAlign: 'left',
  //     },
  //   ]

  //   if (error) {
  //     return <div>{error}</div>
  //   }
  if (!Array.isArray(rows) || !rows.length) {
    return <div></div>
  }
  // let { policies: records = [] } = data
  return (
    <div style={{ height: '50em', width: '100%' }}>
      <DataGrid
        getRowId={(row) => row[pk]}
        columns={cols}
        rows={rows}
        sortModel={[{ field: pk, sort: 'asc' }]}
      />
    </div>
  )
}

export { GenericDataGrid }
