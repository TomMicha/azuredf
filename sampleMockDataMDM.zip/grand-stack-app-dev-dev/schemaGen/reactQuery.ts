export type Maybe<T> = T | null;
export type Exact<T extends { [key: string]: unknown }> = { [K in keyof T]: T[K] };
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]?: Maybe<T[SubKey]> };
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]: Maybe<T[SubKey]> };
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: string;
  String: string;
  Boolean: boolean;
  Int: number;
  Float: number;
  DateTime: any;
  Point: any;
  PointInput: any;
};

export type Business = {
  __typename?: 'Business';
  businessId: Scalars['ID'];
  name: Scalars['String'];
  address?: Maybe<Scalars['String']>;
  city?: Maybe<Scalars['String']>;
  state?: Maybe<Scalars['String']>;
  location?: Maybe<Scalars['Point']>;
  avgStars?: Maybe<Scalars['Float']>;
  reviews?: Maybe<Array<Maybe<Review>>>;
  categories?: Maybe<Array<Maybe<Category>>>;
};

export type Category = {
  __typename?: 'Category';
  name: Scalars['ID'];
  businesses?: Maybe<Array<Maybe<Business>>>;
};


export type Mutation = {
  __typename?: 'Mutation';
  mergeBusinessCategory?: Maybe<Business>;
  mergeUser?: Maybe<User>;
  mergeBusiness?: Maybe<Business>;
};


export type MutationMergeBusinessCategoryArgs = {
  categories: Array<Scalars['String']>;
  businessId: Scalars['ID'];
};


export type MutationMergeUserArgs = {
  name: Scalars['String'];
  userId: Scalars['ID'];
};


export type MutationMergeBusinessArgs = {
  businessId: Scalars['ID'];
  name: Scalars['String'];
  address: Scalars['String'];
  city: Scalars['String'];
  state: Scalars['String'];
  latitude: Scalars['Float'];
  longitude: Scalars['Float'];
};



export type Query = {
  __typename?: 'Query';
  gnomeCount: Scalars['Int'];
  gnomeName: Scalars['String'];
  userCount: Scalars['Int'];
  userCount2: Scalars['Int'];
  ratingsCount?: Maybe<Array<Maybe<RatingCount>>>;
};

export type RatingCount = {
  __typename?: 'RatingCount';
  stars: Scalars['Float'];
  count: Scalars['Int'];
};

export type Review = {
  __typename?: 'Review';
  reviewId: Scalars['ID'];
  stars?: Maybe<Scalars['Float']>;
  text?: Maybe<Scalars['String']>;
  date?: Maybe<Scalars['DateTime']>;
  business?: Maybe<Business>;
  user?: Maybe<User>;
};

export type User = {
  __typename?: 'User';
  userId: Scalars['ID'];
  name?: Maybe<Scalars['String']>;
  reviews?: Maybe<Array<Maybe<Review>>>;
  avgStars?: Maybe<Scalars['Float']>;
  numReviews?: Maybe<Scalars['Int']>;
  recommendations?: Maybe<Array<Maybe<Business>>>;
};


export type UserRecommendationsArgs = {
  first?: Maybe<Scalars['Int']>;
};
