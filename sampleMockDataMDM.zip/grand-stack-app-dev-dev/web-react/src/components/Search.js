import React, {Component} from 'react'
import { useQuery, gql } from '@apollo/client'

const ResultsWithQuery = gql`
    query FindNode($query: String!) {
        search(query: $query, type: User) {
            name
    }
}
`

export default class Search extends Component {
    constructor(props) {
        super(props)
        this.state = {
            search: ''
        }
    }
    
    updateSearch = (e) => {
        this.setState({
            search: e.target.value
        })
    }
    
    submitSearch = (e) => {
        e.preventDefault()
        console.log(this.state)
    }
    render() {

        const {search} = this.state;
    
        return (
            <div>
                <form onSubmit={this.submitSearch}>
                <input
                    type='text'
                    onChange={this.updateSearch}
                    value={search}
                    placeholder='Search'
                />
                <ResultsWithQuery query={search} />
            </form>
            <p>add counts of entity here with list of entities/nodes that exist</p> 
            </div>
        )
    }
}