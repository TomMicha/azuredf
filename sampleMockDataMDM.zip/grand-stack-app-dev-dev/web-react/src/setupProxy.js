const proxy = require('http-proxy-middleware')

console.log("proxy:"+process.env.PROXY)
module.exports = function (app) {
  app.use(
    '/graphql',
    proxy({
      target: `${process.env.PROXY}`,
      changeOrigin: true,
    })
  )
}
