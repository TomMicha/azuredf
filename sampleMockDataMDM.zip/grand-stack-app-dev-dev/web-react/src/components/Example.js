import React from 'react'
import { useQuery, gql } from '@apollo/client'

export const MY_QUERY = gql`
  query SearchQuery($queryString: String!) {
    search(query: $queryString, type: LOCATION, first: 10) {
      edges {
        node {
          ... on Repository {
            name
            description
            stargazers {
              totalCount
            }
          }
        }
      }
    }
  }
`

export function TopProjects(query) {
  const { loading, error, data } = useQuery(MY_QUERY, {
    variables: {
      queryString: query,
    },
  })

  if (loading) {
    return <p>Loading...</p>
  }

  if (error) {
    return <p>Oh no!</p>
  }

  return (
    <ul>
      {data.search.edges.map(({ node }) => (
        <li key={node.name}>
          {node.description} | {node.stargazers.totalCount} Stars
        </li>
      ))}
    </ul>
  )
}
