import { gql } from '@apollo/client'

const getPolicyCount = gql`
  query {
    policiesCount
  }
`
const getPolicies = gql`
  fragment PolicyStateFields on PolicyState {
    policyStatus
    # policyYear
    policyPeriodStarts
    policyPeriodEnds
    policyCoverageStarts
    policyCoverageEnds
  }

  query getPolicies(
    $first: Int
    $offset: Int
    $orderBy: [PolicySort]
    $filter: PolicyWhere
  ) {
    policies(
      options: { limit: $first, offset: $offset, sort: $orderBy }
      where: $filter
    ) {
      policyVersionSk
      # policyNumber
      currentState {
        ...PolicyStateFields
      }
    }
  }
`

const getUnmasteredPolicyCount = gql`
  query {
    unmasteredPolicyCount
  }
`

export { getPolicyCount, getPolicies, getUnmasteredPolicyCount }
