import React from 'react'
import Table from '@material-ui/core/Table'
import TableBody from '@material-ui/core/TableBody'
import TableCell from '@material-ui/core/TableCell'
import TableHead from '@material-ui/core/TableHead'
import TableRow from '@material-ui/core/TableRow'
import { useQuery, gql } from '@apollo/client'
//import { makeStyles } from '@material-ui/core/styles'
//import { Link } from 'react-router-dom'
import Title from './Title'
//import moment from 'moment'
// const useStyles = makeStyles({
//   depositContext: {
//     flex: 1,
//   },
//   navLink: {
//     textDecoration: 'none',
//   },
// })

const CITY_REGION_QUERY = gql`
  {
    cityRegionStates(options: { limit: 20, sort: { modified: DESC } }) {
      id
      city
      state
      country
      modified
    }
  }
`
// past: <TableCell>{moment(row.date).format('MMMM Do YYYY')}</TableCell>
export default function RecentCities() {
  //const { classes } = useStyles()
  const { loading, error, data } = useQuery(CITY_REGION_QUERY)
  if (error) return <p>Error</p>
  if (loading) return <p>Loading</p>

  return (
    <React.Fragment>
      <Title>City/Region Locations</Title>
      <Table size="small">
        <TableHead>
          <TableRow>
            <TableCell>id</TableCell>
            <TableCell>city</TableCell>
            <TableCell>state</TableCell>
            <TableCell>country</TableCell>
            <TableCell>modified</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {data.cityRegionStates.map((row) => (
            <TableRow key={row.id}>
              <TableCell>{row.id}</TableCell>
              <TableCell>{row.city}</TableCell>
              <TableCell>{row.state}</TableCell>
              <TableCell>{row.country}</TableCell>
              <TableCell>{row.modified}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </React.Fragment>
  )
}
