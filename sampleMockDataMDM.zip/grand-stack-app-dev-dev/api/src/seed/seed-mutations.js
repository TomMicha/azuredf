const fetch = require('node-fetch')
const parse = require('csv-parse/lib/sync')
const { gql } = require('@apollo/client')

export const getSeedMutations = async () => {
  const res = await fetch(
    'https://raw.githubusercontent.com/TomMicha/azuredf/master/MOCK_DATA_loc.csv'
  )
  const body = await res.text()
  const records = parse(body, { columns: true })
  const mutations = generateMutations(records)
  
  return mutations
}
//var count = 0  // should i trim all whitespace here?
const generateMutations = (records) => {
  return records.map((rec) => {
    Object.keys(rec).map((k) => {
      if (k === 'latitude' || k === 'longitude' ) {
        rec[k] = parseFloat(rec[k])
      } else if (k === 'updated') {
        const dateParts = rec[k].split('-')
        rec['year'] = parseInt(dateParts[0])
        rec['month'] = parseInt(dateParts[1])
        rec['day'] = parseInt(dateParts[2])
        //++count
        //console.log(count)
      }
    })
    //console.log("finished first part of mutations")
    return {
      mutation: gql`
        mutation mergeLocations(
          $id: Int
          $address: String
          $source: String
          $city: String
          $country: String
          $zip: String
          $sourceId: String
          $state: String
          $longitude: Float
          $latitude: Float
          $updated: DateTime!
        ) {
          location: mergeLocation(
            locationId: $id
            address: $address
            source: $source
            city: $city
            country: $country
            zip: $zip
            sourceId: $sourceId
            state: $state
            longitude: $longitude
            latitude: $latitude
            updated: $updated
    ) {
            address
          }
          cityState: mergeCityState(
            id: $id
            city: $city
            country: $country
            state: $state){
            city
          }
          geoLocations: createGeoLocations(
            input: {
              geoId: $id
              longitude: $longitude
              latitude: $latitude
              date: $reviewDate
              locations: { connect: { where: { locationsId: $locationId } } }
            }
          ) {
            geoLocations {
              geoId
            }
          }
        }
      `,
      variables: rec,
    }
  })
}
